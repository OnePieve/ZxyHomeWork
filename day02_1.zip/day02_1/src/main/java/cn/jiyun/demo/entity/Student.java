package cn.jiyun.demo.entity;

import lombok.*;

/**
 * @version V1.0
 * @ClassName Student
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/14 16:13
 */

@Data
public class Student {

	private String stuId;

	private String stuName;

	private String stuAge;

	private String stuClsId;

	private Classes cls;

	private String stuOrigin;

	private String stuAddress;

	private String stuPhone;


}
