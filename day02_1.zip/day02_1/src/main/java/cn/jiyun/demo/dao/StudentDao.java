package cn.jiyun.demo.dao;

import cn.jiyun.demo.entity.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentDao {

	@Select("select stuId, stuName, stuAge, stuClsId, stuOrigin, stuAddress, stuPhone from student")
	List<Student> findAll();

	@Delete("delete from student where stuId = #{id}")
	int deleteById(Integer id);

	@Update("update student set stuName = #{stuName} where stuId = #{stuId};")
	int editStudent(Student stu);

	@Insert("insert into student (stuId, stuName, stuAge, stuClsId, stuOrigin, stuAddress, stuPhone) values (#{stuId},#{stuName}" +
			",#{stuAge},#{stuClsId},#{stuOrigin},#{stuAddress},#{stuPhone});")
	int addStudent(Student stu);
}
