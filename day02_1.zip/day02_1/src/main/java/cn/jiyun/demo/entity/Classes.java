package cn.jiyun.demo.entity;

import lombok.Data;

/**
 * @version V1.0
 * @ClassName Classes
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 14:10
 */

@Data
public class Classes {

	private String clsId;

	private String claName;



}
