package cn.jiyun.demo.service;

import cn.jiyun.demo.entity.Student;

import java.util.List;

public interface StudentService {

	List<Student> findAll();

	int addStudent(Student stu);

	int editStudent(Student stu);


	int deleteById(int i);
}
