package cn.jiyun.demo.controller;

import cn.jiyun.demo.entity.Student;
import cn.jiyun.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @version V1.0
 * @ClassName StudentController
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/14 16:14
 */

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	StudentService studentService;

	@RequestMapping("/findAll")
	public Object findAll(){

		List<Student> list = studentService.findAll();

		//System.out.println("___________________________________________________________________");

		return list;

	}


	@RequestMapping("/addStudent")
	public Object addStudent(Student student){

		Student stu = new Student();

		stu.setStuId("1");
		stu.setStuName("张三");
		stu.setStuAge("12");
		stu.setStuClsId("1");
		stu.setStuOrigin("一般");
		stu.setStuAddress("北京");
		stu.setStuPhone("10086");

		int i = studentService.addStudent(stu);

		if (i>0) {
		    return "OK";
		}else {
			return "Error";
		}

	}


	@RequestMapping("/editStudent")
	public Object editStudent(Student student){

		Student stu = new Student();

		stu.setStuId("1");
		stu.setStuName("李四");

		int i = studentService.editStudent(stu);

		if (i>0) {
		    return "OK";
		}else {
			return "Error";
		}

	}


	@RequestMapping("/deleteById")
	public Object deleteById(){

		int i = studentService.deleteById(1);

		if (i>0) {
		    return "OK";
		}else {
			return "Error";
		}

	}

}
