package cn.jiyun.demo.entity;

import lombok.Data;

import java.util.List;

/**
 * @version V1.0
 * @ClassName Student
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:33
 */

@Data
public class Student {

	private int stuId;

	private String stuName;

	private int stuAge;

	private int stuClsId;

	private String stuOrigin;

	private String stuAddress;

	private String stuPhone;
/*
	private List<Score> scoreList;

	private Classes classes;*/




}
