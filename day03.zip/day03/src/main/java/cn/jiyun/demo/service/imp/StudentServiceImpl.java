package cn.jiyun.demo.service.imp;

import cn.jiyun.demo.dao.StudentDao;
import cn.jiyun.demo.entity.Student;
import cn.jiyun.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @version V1.0
 * @ClassName StudentServiceImpl
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:33
 */

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;

	@Override
	public List<Student> findAll() {
		return studentDao.findAll();
	}

	@Override
	public int addStudent(Student stu) {
		return studentDao.addStudent(stu);
	}

	@Override
	public int editStudent(Student stu) {
		return studentDao.editStudent(stu);
	}

	@Override
	public int deleteById(int i) {
		return studentDao.deleteById(i);
	}


}
