package cn.jiyun.demo.dao;

import cn.jiyun.demo.entity.Student;

import java.util.List;
import java.util.Map;

/**
 * @version V1.0
 * @ClassName StudentDao
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:34
 */
public interface StudentDao {

	List<Student> findAll();

	int addStudent(Student stu);

	int editStudent(Student stu);

	int deleteById(Integer student);
}
