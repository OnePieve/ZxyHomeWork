package cn.jiyun.demo.controller;

import cn.jiyun.demo.entity.Student;
import cn.jiyun.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @version V1.0
 * @ClassName StudentController
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:34
 */

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	StudentService studentService;

	@CrossOrigin
	@RequestMapping("/findAll")
	public Object findAll(){

		//System.out.println("#################################################################");

		List<Student> list = studentService.findAll();

		//System.out.println("#################################################################");

		return list;

	}

	@CrossOrigin
	@RequestMapping("/addStudent")
	public Object addStudent(Student student){

		Student stu = new Student();
		stu.setStuId(1002);
		stu.setStuName("迪迦");
		stu.setStuAge(12);
		stu.setStuClsId(2);
		stu.setStuOrigin("好");
		stu.setStuAddress("北京");
		stu.setStuPhone("10034");

		int i = studentService.addStudent(stu);

		if (i>0) {

			return "OK";

		}else {

			return "Error";

		}

	}

	@CrossOrigin
	@RequestMapping("/editStudent")
	public Object editStudent(Student student){

		Student stu = new Student();

		stu.setStuId(1);

		stu.setStuName("Carry");

		int i = studentService.editStudent(stu);

		if (i>0) {

			return "OK";

		}else {

			return "Error";

		}

	}

	@CrossOrigin
	@RequestMapping("/deleteById")
	public Object deleteById(Integer student){

		int i = studentService.deleteById(1);

		if (i>0) {

			return "OK";

		}else {

			return "Error";

		}

	}

}
