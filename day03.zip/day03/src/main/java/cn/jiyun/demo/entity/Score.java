package cn.jiyun.demo.entity;

import lombok.Data;

/**
 * @version V1.0
 * @ClassName Score
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:33
 */

@Data
public class Score {

	private int scId;

	private int score;

	private int subject;

}
