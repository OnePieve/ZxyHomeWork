package cn.jiyun.demo.entity;

import lombok.Data;

/**
 * @version V1.0
 * @ClassName Classes
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/15 16:33
 */

@Data
public class Classes {

	private int clsId;

	private String clsName;



}
