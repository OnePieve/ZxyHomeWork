package cn.jiyun.demo.service.imp;

import cn.jiyun.demo.dao.StudentDao;
import cn.jiyun.demo.entity.Student;
import cn.jiyun.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @version V1.0
 * @ClassName StudentServiceImpl
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/16 16:05
 */

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;

	@Override
	public int deleteById(Integer id) {
		return studentDao.deleteById(id);
	}

	@Override
	public int editStudent(Student student) {
		return studentDao.editStudent(student);
	}

	@Override
	public int addStudent(Student student) {
		return studentDao.addStudent(student);
	}

	@Override
	public List<Student> findAll() {
		return studentDao.findAll();
	}
}
