package cn.jiyun.demo.entity;

import lombok.Data;

@Data
public class Classes {
	/**
	 *
	 */
	private Integer clsId;

	/**
	 * 班级名称
	 */
	private String clsName;
}

