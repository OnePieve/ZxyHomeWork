package cn.jiyun.demo.dao;

import cn.jiyun.demo.entity.Student;

import java.util.List;
import java.util.Map;

public interface StudentDao {

	List<Student> findAll();

	int addStudent(Student student);

	int editStudent(Student student);

	int deleteById(Integer id);
}
