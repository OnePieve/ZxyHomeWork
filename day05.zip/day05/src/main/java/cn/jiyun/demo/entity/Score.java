package cn.jiyun.demo.entity;

import lombok.Data;

@Data
public class Score {
	/**
	 *
	 */
	private Integer scId;

	/**
	 * 分数
	 */
	private Integer score;

	/**
	 * 学生ID
	 */
	private Integer stuId;

	/**
	 * 科目
	 */
	private String subject;
}

