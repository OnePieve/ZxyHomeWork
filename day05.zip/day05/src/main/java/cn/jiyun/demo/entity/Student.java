package cn.jiyun.demo.entity;

import lombok.Data;

import java.util.List;

@Data
public class Student {
	/**
	 * id
	 */
	private Integer stuId;

	/**
	 * 姓名
	 */
	private String stuName;

	/**
	 * 年龄
	 */
	private Integer stuAge;

	/**
	 * 班级Id
	 */
	private Integer stuClsId;

	/**
	 * 籍贯
	 */
	private String stuOrigin;

	/**
	 * 住址
	 */
	private String stuAddress;

	/**
	 * 电话
	 */
	private String stuPhone;

	private Classes classes;

	private List<Score> score;

}

