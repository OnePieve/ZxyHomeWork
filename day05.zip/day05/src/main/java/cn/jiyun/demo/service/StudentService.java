package cn.jiyun.demo.service;

import cn.jiyun.demo.entity.Student;

import java.util.List;

public interface StudentService {
	int deleteById(Integer id);

	int editStudent(Student student);

	int addStudent(Student student);

	List<Student> findAll();
}
