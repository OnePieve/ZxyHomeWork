package cn.jiyun.demo.dao;

import cn.jiyun.demo.entity.Student;

import java.util.List;

public interface StudentDao {
	
	int addStudent(Student student);

	List<Student> findAll();

	int editStudent(Student student);

	int deleteById(Integer id);
}
