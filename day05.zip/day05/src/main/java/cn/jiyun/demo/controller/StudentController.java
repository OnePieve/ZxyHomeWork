package cn.jiyun.demo.controller;

import cn.jiyun.demo.entity.Student;
import cn.jiyun.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @version V1.0
 * @ClassName StudentController
 * @Description TODO
 * @Author Jay
 * @Date 2022/9/19 18:38
 */

@RestController
@RequestMapping("student")
public class StudentController {

	@Autowired
	StudentService studentService;

	@CrossOrigin
	@RequestMapping("/findAll")
	public Object findAll(){

		List<Student> list = studentService.findAll();

		return list;

	}

	@CrossOrigin
	@RequestMapping("/addStudent")
	public Object addStudent(@RequestBody Student student){

		int i = 0;

		i = studentService.addStudent(student);

		return i;

	}

	@CrossOrigin
	@RequestMapping("/editStudent")
	public Object editStudent(@RequestBody Student student){

		int i = 0;

		i = studentService.editStudent(student);

		return i;

	}

	@CrossOrigin
	@RequestMapping("/deleteById/{id}")
	public Object deleteById(@PathVariable("id") Integer stuId){

		int i = 0;

		i = studentService.deleteById(stuId);

		return i;

	}


}
